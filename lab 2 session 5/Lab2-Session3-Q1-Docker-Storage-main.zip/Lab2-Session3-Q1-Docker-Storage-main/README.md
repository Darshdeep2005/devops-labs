# Lab 2 – Session 3 – Question 1
## Docker Storage: Container Layer, Named Volume, and Bind Mount

### Objective
Demonstrate:
1. Data loss when data is stored in a container's writable layer and the container is deleted.
2. Persistent storage using a Docker named volume.
3. Persistent storage using a bind mount to a host directory.

---

## 1. Container Writable Layer (Data Loss)

Run a container:

```bash
docker run -it --name storage1 ubuntu bash
```

Inside the container:

```bash
echo "Hello Docker Storage" > data.txt
cat data.txt
exit
```

Remove the container:

```bash
docker rm storage1
```

Create a new container with the same name:

```bash
docker run -it --name storage1 ubuntu bash
```

Check the old file:

```bash
cat data.txt
```

**Observation:** The file is not found. Data in the container's writable layer is lost when that container is deleted.

Exit and remove the recreated container:

```bash
exit
docker rm storage1
```

---

## 2. Docker Named Volume

Create a named volume:

```bash
docker volume create myvolume
```

Run a container with the volume mounted at `/data`:

```bash
docker run -it --name volume1 -v myvolume:/data ubuntu bash
```

Inside the container:

```bash
echo "Permanent Docker Data" > /data/file.txt
cat /data/file.txt
exit
```

Remove the first container:

```bash
docker rm volume1
```

Start another container with the same named volume:

```bash
docker run -it --name volume2 -v myvolume:/data ubuntu bash
```

Verify:

```bash
cat /data/file.txt
```

**Observation:** The data remains available after deleting the original container because it is stored in the named volume.

---

## 3. Bind Mount

Create a directory on the Mac host:

```bash
mkdir -p ~/docker-lab-storage
```

Run a container with the host folder mounted into `/data`:

```bash
docker run -it --name bind1 -v "$HOME/docker-lab-storage:/data" ubuntu bash
```

Inside the container:

```bash
echo "Bind Mount Permanent Data" > /data/file.txt
cat /data/file.txt
exit
```

Verify the file from the Mac host:

```bash
cat ~/docker-lab-storage/file.txt
```

Remove the container:

```bash
docker rm bind1
```

Recreate it using the same bind mount:

```bash
docker run -it --name bind2 -v "$HOME/docker-lab-storage:/data" ubuntu bash
```

Verify inside the recreated container:

```bash
cat /data/file.txt
```

**Observation:** The file persists because it is stored in the host directory and mounted into the container.

---

## Conclusion

Docker container writable-layer data is temporary and is lost when a container is deleted. Docker named volumes and bind mounts provide persistent storage beyond a container's lifecycle. Named volumes are managed by Docker, while bind mounts connect a container directory to a specific host directory.
