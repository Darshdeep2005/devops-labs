# Results and Observations

## 1. Container writable layer
- Created `data.txt` inside `storage1`.
- Deleted the container and recreated it.
- `cat data.txt` returned: `No such file or directory`.
- **Result:** Data stored only in the container writable layer was lost after deletion.

## 2. Named volume
- Created the named volume `myvolume`.
- Saved `Permanent Docker Data` in `/data/file.txt`.
- Deleted `volume1` and attached the same volume to `volume2`.
- The file was still readable.
- **Result:** Named-volume data persisted across container deletion.

## 3. Bind mount
- Created host folder `~/docker-lab-storage`.
- Mounted it into the container at `/data`.
- Saved `Bind Mount Permanent Data` to `/data/file.txt`.
- Verified the same file from the Mac host using `cat ~/docker-lab-storage/file.txt`.
- Recreated a container with the same bind mount and verified the file again.
- **Result:** Bind-mounted data persisted on the host and was accessible from the recreated container.

## Conclusion
Container writable-layer storage is ephemeral. Docker named volumes and bind mounts allow data to persist beyond the lifecycle of a container.
