# Lab 2 – Session 4 – Question 2
## Docker Container and Image Management

### Objective
To manage Docker containers and images, tag and push a Docker image to Docker Hub, and run a multi-container application using Docker Compose.

### Docker commands demonstrated
- `docker ps` – list running containers
- `docker ps -a` – list all containers
- `docker start container1` – start a container
- `docker stop container1` – stop a container
- `docker rm container1` – remove a stopped container
- `docker images` – list local images
- `docker tag alpine adityakamboj/alpine-lab:latest` – tag an image
- `docker login` – sign in to Docker Hub
- `docker push adityakamboj/alpine-lab:latest` – push the image to Docker Hub

### Docker Compose setup
This Compose project runs:
- **Nginx** web server, published on port `8080`
- **Redis** service

### Start services
```bash
docker compose up -d
```

### Check services
```bash
docker compose ps
```

### Test
Open this address in a browser:
http://localhost:8080

### Stop the project
```bash
docker compose down
```
