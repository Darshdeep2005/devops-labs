# Lab 3 — Session 1 — Question 1
## Monitoring with Prometheus and Grafana

This project runs Prometheus and Grafana using Docker Compose.

### Prerequisites
- Docker Desktop installed and running
- Docker Compose available through Docker Desktop

### Start
From this folder, run:

```bash
docker compose up -d
docker ps
```

### Open services
- Prometheus: http://localhost:9090
  - Query `up` and click Execute. A value of `1` means the target is up.
- Grafana: http://localhost:3000
  - Default login: `admin` / `admin` (change password when prompted)

The Prometheus data source is provisioned automatically in Grafana.
A dashboard named **Lab 3 - Prometheus Monitoring** is provisioned from the included JSON file.

### Dashboard queries
1. Target status: `up`
2. CPU activity: `rate(process_cpu_seconds_total[5m])`
3. Memory usage: `process_resident_memory_bytes`

### Stop
```bash
docker compose down
```

### Optional: remove container data
This setup does not configure persistent Prometheus/Grafana data volumes. If you add volumes later, use `docker compose down -v` only if you intentionally want to remove those stored volumes.

### Submission evidence
Add your own screenshots to a folder named `screenshots/` before submitting:
- Prometheus query showing `up`
- Grafana data source successful test
- Grafana dashboard with all panels
- Terminal output from `docker ps`

The dashboard JSON included here is a reproducible configuration. It may not exactly match the dashboard you manually built in Grafana.
